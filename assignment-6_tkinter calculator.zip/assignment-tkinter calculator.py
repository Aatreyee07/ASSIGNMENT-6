from tkinter import *
window =Tk()
window.geometry('500x500')
a = Entry(window, width =60 ,borderwidth =5)
a.place(x=0, y=0)

b=Button(window, text='1', width=10)
b.place(x=0, y=30)
